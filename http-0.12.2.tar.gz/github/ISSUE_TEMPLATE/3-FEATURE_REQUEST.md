---
name: I'd like a new feature.
about: You are using `package:http` and would like a new feature to make it
  easier to make http requests.

---

<!--
  Please describe the feature you'd like to see us implement along with a use
  case.


  Note that this package is designed to be cross-platform and we will only be
  able to add features which can be supported with _both_ `dart:io` and
  `dart:html`. If you're looking for a feature which is already supported by the
  `dart:io` HttpClient constructor you can construct one manually and pass it
  to the IOClient constructor directly.
-->
